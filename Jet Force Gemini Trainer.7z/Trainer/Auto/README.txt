"Drive.bat" is the script to use this utility.

It will ask for the paths of several things and other information it needs to generate scripts (currently only batch scripts for Windows users) to speed up the process of using the Trainer, its sample hack, and previously, the online enable hack for the sample hack (which has been deprecated), as well as undoing these patches.

When it asks for the path of a utility, such as the Z64 converter, give the path to the associated ".class" file - the one with the same name (but not extension) as the source file for that utility.

The source file for the Z64 converter, for example, is called "JFG_to_Z64.java" - so you would give the path to "JFG_to_Z64.class" when the utility asks you to give the path to "the Z64 converter".

The names of the generates scripts should be rather explanatory about what they're for.

Any invalid arguments to this utility should simply cause the scripts that require them to not be generated, but this is not guaranteed. Testing was only done to ensure the utility works if used completely and correctly (you can supply dummy arguments if you must).

This utility may have the arguments it need supplied to it from the command line if desired, although that would somewhat defeat the purpose of this utility.
