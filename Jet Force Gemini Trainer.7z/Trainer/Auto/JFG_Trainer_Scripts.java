/**
 * JFG_Trainer_Scripts by Hextator
 * Public domain
 * Generates scripts (currently only for Windows) for automating the use
 * of the utilities for applying and unapplying the Jet Force Gemini Trainer,
 * the Co-Op hack, and the online play enabling hack for the Co-Op hack
**/

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.NumberFormat;
import java.util.Arrays;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class JFG_Trainer_Scripts {
	// Constants

	public static final String SAVE_NAME = "JET FORCE GEMINI     (unknown rom).fla";

	// General utility functions

	// XXX Refactor into library

	public static String newline = System.getProperty("line.separator");

	public static boolean DEBUG = false;

	private static String log(String message) {
		if (DEBUG) System.out.println(message);
		return message;
	}

	public static String quoted(String input) {
		if (input == null) return null;
		return "\"" + input + "\"";
	}

	public static String pathWithoutExt(String path) {
		boolean hasExt = true;
		int index = -1;
		try {
			File test = new File(path);
			if (!test.exists())
				throw new RuntimeException("File doesn't exist");
			String name = test.getName();
			index = name.lastIndexOf('.');
			if (index == -1)
				hasExt = false;
		} catch (Exception ex) { }
		if (hasExt) {
			index = path.lastIndexOf('.');
			if (index != -1)
				return path.substring(0, index);
		}
		return path;
	}

	public static int parseInt(String input) {
		input = input.trim();
		int base = 10;
		if (input.indexOf("0x") == 0) {
			base = 16;
			input = input.substring(2);
		}

		return Integer.parseInt(input, base);
	}

	public static int __argIndex = 0;

	public static abstract class FetchArgument {
		public abstract Object fetch(String description);
	}

	public static abstract class StringArgConverter {
		public abstract Object convert(String input);
	}

	public static abstract class NumberGetter {
		public abstract Number get(String desc);
	}

	public static abstract class NumberVerifier {
		public abstract boolean verify(Number input);
	}

	public static abstract class
	AutomaticResourceManager<T extends java.io.Closeable> {
		public abstract T create() throws Exception;
		public abstract void execute(T obj) throws Exception;

		public AutomaticResourceManager() {
			T obj = null;
			try {
				obj = create();
				execute(obj);
			} catch (Exception ex) { } finally {
				if (obj != null) {
					try {
						obj.close();
					} catch (Exception ex) { }
				}
			}
		}
	}

	public static Object initializeFromArgument(
		String[] args, int index,
		FetchArgument fetch, String description,
		StringArgConverter converter
	) {
		__argIndex = index + 1;
		Object output = null;
		String obtained = null;
		try {
			obtained = args[index];
		} catch (Exception ex) { }
		if (obtained != null && !obtained.isEmpty()) {
			output = converter.convert(obtained);
		}
		if (output == null)
			output = fetch.fetch(description);
		return output;
	}

	public static Object initializeFromArgument(
		String[] args,
		FetchArgument fetch, String description,
		StringArgConverter converter
	) {
		return initializeFromArgument(
			args, __argIndex,
			fetch, description,
			converter
		);
	}

	private static File fileHelper(String title, int mode) {
		java.awt.FileDialog chooser = new java.awt.FileDialog(
			new java.awt.Frame(), title, mode
		);
		chooser.setVisible(true);
		chooser.setLocationRelativeTo(null);

		String directory = chooser.getDirectory();
		String file = chooser.getFile();

		if (directory == null || file == null) { return null; }
		return new File(directory + file);
	}

	private static File dirHelper(String title) {
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle(title);
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) { 
			return chooser.getSelectedFile();
		}
		return null;
	}

	public static File showOpenFileDialog(String what) {
		return fileHelper(
			"Select " + what + " for opening",
			java.awt.FileDialog.LOAD
		);
	}

	public static File showSaveFileDialog(String what) {
		return fileHelper(
			"Select path to save " + what,
			java.awt.FileDialog.SAVE
		);
	}

	public static File showOpenDirDialog(String what) {
		return dirHelper(
			"Select directory of " + what
		);
	}

	public static File getRequiredFile(String[] args, String desc) {
		return (File)initializeFromArgument(
			args,
			new FetchArgument() {
				@Override
				public Object fetch(String description) {
					return showOpenFileDialog(description);
				}
			},
			desc,
			new StringArgConverter() {
				@Override
				public Object convert(String input) {
					return input;
				}
			}
		);
	}

	public static File getFile(String[] args, String desc) {
		return (File)initializeFromArgument(
			args,
			new FetchArgument() {
				@Override
				public Object fetch(String description) {
					return showSaveFileDialog(description);
				}
			},
			desc,
			new StringArgConverter() {
				@Override
				public Object convert(String input) {
					return input;
				}
			}
		);
	}

	public static File getDirectory(String[] args, String desc) {
		return (File)initializeFromArgument(
			args,
			new FetchArgument() {
				@Override
				public Object fetch(String description) {
					return showOpenDirDialog(description);
				}
			},
			desc,
			new StringArgConverter() {
				@Override
				public Object convert(String input) {
					return input;
				}
			}
		);
	}

	private static int pollForInt(String message) {
		int output;
		while (true) {
			try {
				output = parseInt(javax.swing.JOptionPane.showInputDialog(
					message
				));
			} catch (Exception e) { continue; }
			break;
		}
		return output;
	}

	public static Number getNumber(
		String[] args,
		final NumberGetter getter, final NumberVerifier ver,
		String desc
	) {
		return (Number)initializeFromArgument(
			args,
			new FetchArgument() {
				@Override
				public Object fetch(String description) {
					Number saveToUse = getter.get(description);
					if (!ver.verify(saveToUse)) {
						return null;
					}
					return saveToUse;
				}
			},
			desc,
			new StringArgConverter() {
				@Override
				public Object convert(String input) {
					try {
						return NumberFormat.getInstance().parse(input);
					} catch (Exception ex) { }
					return null;
				}
			}
		);
	}

	public static void writeLines(final File outFile, final List<String> lines) {
		new AutomaticResourceManager<FileWriter>() {
			@Override
			public FileWriter create() throws Exception {
				return new FileWriter(outFile);
			}

			@Override
			public void execute(FileWriter obj) throws Exception {
				for (String line : lines)
				obj.write(line + newline);
			}
		};
	}

	// Use this to make drivers
	private static abstract class Run {
		public abstract void execute(String[] args);
	}

	// Methods for program logic

	private static final String DIR = "%[dir]";
	private static final String NAME = "%[name";
	private static String createJavaCMD(File file, String[] args, String toCheck) {
		String dir = null;
		String name = null;
		if (file != null) {
			dir = file.getParentFile().getAbsolutePath();
			name = file.getName();
		}
		if (dir == null || name == null) {
			return log(null);
		}
		for (String curr : args) {
			if (curr == null)
				return log(null);
		}
		toCheck = toCheck.replace(DIR, quoted(dir));
		toCheck = toCheck.replace(NAME, pathWithoutExt(name));
		return log(toCheck);
	}

	// Drivers

	// Tested and working
	private static class ScriptGenerator extends Run {
		public void execute(String[] args) {
			/**
			 * Clean
			 * Z64
			 * Patch
			 * Patcher
			 * Save
			 * Online hack enabler
			**/
			// Get the arguments
			File cleanFile = getRequiredFile(args, "Clean JFG");
			String oldName = cleanFile == null? null : pathWithoutExt(cleanFile.getAbsolutePath());
			File patchedFile = getFile(args, "JFG with Co-Op");
			File netenabledFile = getFile(args, "JFG with Co-Op: Online enabled");
			File Z64cvtFile = getRequiredFile(args, "the Z64 converter");
			File patchFile = getRequiredFile(args, "the Co-Op hack patch");
			File onlineFile = getRequiredFile(args, "the online hack enabler");
			File patcherFile = getRequiredFile(args, "the JFP patcher");
			Number result = getNumber(
				args,
				new NumberGetter() {
					@Override
					public Number get(String desc) {
						return pollForInt(desc);
					}
				},
				new NumberVerifier() {
					@Override
					public boolean verify(Number input) {
						return (input.intValue() >= 1 && input.intValue() <= 6);
					}
				},
				"Give the number of the save you want to use from 1 through 6."
			);
			File saveDir = getDirectory(args, "save file");
			File outDir = getDirectory(args, "where to save created scripts");
			// Convert them
			Integer saveNumber = result == null? null : result.intValue();
			String clean = log(quoted(cleanFile == null? null : cleanFile.getAbsolutePath()));
			String Z64 = null;
			if (cleanFile != null && oldName != null) {
				Z64 = quoted(oldName + ".z64");
			}
			log(Z64);
			String patch = log(quoted(patchFile == null? null : patchFile.getAbsolutePath()));
			String patched = log(quoted(patchedFile == null? null : patchedFile.getAbsolutePath()));
			String save = null;
			if (saveDir != null) {
				save = quoted(saveDir.getAbsolutePath() + File.separator + SAVE_NAME);
			}
			log(save);
			String netenabled = log(quoted(netenabledFile == null? null : netenabledFile.getAbsolutePath()));
			String outpath = null;
			if (outDir != null) {
				outpath = outDir.getAbsolutePath() + File.separator;
			}
			log(outpath);
			// Create the command lines
			String Z64cmd = log(createJavaCMD(
				Z64cvtFile, new String[] { clean, Z64 },
				"cd " + DIR + newline +
				"java " + NAME + " " + clean + " " + Z64
			));
			String patchcmd = log(createJavaCMD(
				patcherFile, new String[] { patch, Z64, patched },
				"cd " + DIR + newline +
				"java " + NAME + " APPLY " + patch + " " + Z64 + " " + patched
			));
			String unpatchcmd = log(createJavaCMD(
				patcherFile, new String[] { patch, patched, Z64 },
				"cd " + DIR + newline +
				"java " + NAME + " APPLY " + patch + " " + patched + " " + Z64
			));
			String onlinecmd = saveNumber == null? null : createJavaCMD(
				onlineFile, new String[] { patched, save, netenabled },
				"cd " + DIR + newline +
				"java " + NAME + " PATCH " + patched + " " + save + " " + saveNumber + " " + netenabled
			);
			log(onlinecmd);
			String offlinecmd = log(createJavaCMD(
				onlineFile, new String[] { netenabled, patched },
				"cd " + DIR + newline +
				"java " + NAME + " UNPATCH " + netenabled + " " + patched
			));
			// Write the scripts
			// Clean to Z64 only
			if (Z64cmd != null) {
				File Z64script = new File(outpath + "JFG to Z64.bat");
				writeLines(Z64script, Arrays.asList(new String[] { Z64cmd }));
			}
			// Z64 to Co-Op only
			if (patchcmd != null) {
				File patchScript = new File(outpath + "Z64 to Co-Op Hack.bat");
				writeLines(patchScript, Arrays.asList(new String[] { patchcmd }));
			}
			// Co-Op to Online Enabled only
			if (onlinecmd != null) {
				File onlineScript = new File(outpath + "Co-Op Hack to Online.bat");
				writeLines(onlineScript, Arrays.asList(new String[] { onlinecmd }));
			}
			// Online Enabled to Co-Op only
			if (offlinecmd != null) {
				File offlineScript = new File(outpath + "Online Enabled Co-Op to Offline.bat");
				writeLines(offlineScript, Arrays.asList(new String[] { offlinecmd }));
			}
			// Co-Op to Z64 only
			if (unpatchcmd != null) {
				File unpatchScript = new File(outpath + "Offline Co-Op to Z64.bat");
				writeLines(unpatchScript, Arrays.asList(new String[] { unpatchcmd }));
			}
			// Z64 to Online
			if (patchcmd != null && onlinecmd != null) {
				File Z64toOnlineScript = new File(outpath + "Z64 to Online Enabled Co-Op Hack.bat");
				writeLines(Z64toOnlineScript, Arrays.asList(new String[] { patchcmd, onlinecmd }));
			}
			// Online to Z64
			if (offlinecmd != null && unpatchcmd != null) {
				File onlineToZ64Script = new File(outpath + "Online Enabled Co-Op Hack to Z64.bat");
				writeLines(onlineToZ64Script, Arrays.asList(new String[] { offlinecmd, unpatchcmd }));
			}
		}
	}

	// Change this and build again to use a different tool,
	// or change it programmatically before calling run.execute(args)
	// to simulate multiple utilities
	private static Run run = new ScriptGenerator();

	// Main

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(
				UIManager.getSystemLookAndFeelClassName()
			);
			run.execute(args);
		} catch (Exception e) {
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			JTextArea errorDisplayArea = new JTextArea(
				"Exception: " +
				e.getMessage() +
				"\n" +
				result.toString()
			);
			JScrollPane errorPane = new JScrollPane(errorDisplayArea);
			JOptionPane.showMessageDialog(
				null,
				errorPane,
				"Error",
				JOptionPane.ERROR_MESSAGE
			);
		}
		System.exit(0);
	}
}
