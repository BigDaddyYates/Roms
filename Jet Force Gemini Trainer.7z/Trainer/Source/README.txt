IMPORTANT NOTE: This README assumes that you are working with the .z64 (big endian) version of the ROM. If you aren't, convert it - there is a program for this in the "Z64" directory of this folder's parent folder and the README in this folder's parent folder explains how to use it.

~~~~~

This hack modifies {checksum protected code} to load (code) which hooks [code which is executed each frame] to <code> stored at the end of the ROM outside of the {checksum protected area}.

The hooked-to <code> then loads a "cheat list" from even later in the ROM and processes it each frame, just like a GameShark.

Because of how this system works, it can be used to create ROM hacks which apply cheat codes, but the cheat code format is enhanced and custom made. It does not match the same cheat code specification the GameShark uses but rather improves upon it significantly.

Source and a completed sample hack is included. There is currently no support for TLB codes though it should be trivial to add it due to the readily update-able nature of the implementation of the hack (since the trainer <code> and "cheat list" are both expected to be stored outside of a {checksum protected area} and are stored in the ROM and loaded into the RAM at locations with several kilobytes of free space).

The latest version of the hack (at least from the original author) can always be found [url=http://dl.dropbox.com/u/336940/Jet%20Force%20Gemini%20Trainer.7z]here[/url].

The way the trainer loads seems to require implementing hacks to have register caching disabled for the ROM in Project 64. Other oddities of using the trainer such as graphics plugins not recognizing the ROM and which settings to use are noted in the various README files throughout the release.

Also note that implementing hacks may not run in the interpreter mode of Project 64, although the recompiler core works fine (and runs faster anyway).

The sample hack which is included is a fully operable hack for playing through the game's single player mode with more than one player as one of the Jet Force team members (as opposed to Floyd) with support for up to 4 players.

There are instructions for getting the hack working both offline and online included.

If you are having problems with the hack, check for updates often as I am doing a second playthrough of the hack to round up any information about it I may have missed the first time around and regularly update the documentation as I find things.

If you still can't figure out how to get around a problem, contact me on AIM ("hextator") or MSN ("hextator@gmail.com") and ask for help. This will help me keep the documentation updated as well as letting me help out.

~~~~~

Use these settings for the ROM (names of options taken from Project 64 v 1.6):

CPU core style: Recompiler
Self-modifying code Method: Check Memory & Cache
Memory Size: 8 MB - 4 MB will crash
Advanced Block Linking: Default
Default Save type: Use First Used Save Type
Counter Factor: 2
Large Compile Buffer: OFF
Use TLB: OFF
Register Caching: OFF; this has to be off for the trainer to work anyway.
SP Hack: OFF
RSP Audio Signal: OFF

~~~~~

WARNING: The trainer currently requires the ROM's checksums to be recalculated. Attempts to get around this need have been made with no success (see the "Failed Attempt 1" folder).

Because it modifies the checksum, the hardcoded, terribly programmed graphics plugins such as Jabo's version 1.6 D3D8 plugin commonly used by N64 emulators will not recognize the game and will not handle it correctly.

As such, hacks implementing the trainer will give players difficulty viewing the bosses and navigating the night vision area of the game as player 1 will have a black screen when certain plugins are used unless the settings for those plugins are tweaked by choosing to "configure [the] graphics plugin" in the emulators' options windows. Configurations which work are detailed below.

~~~~~

One plugin that DOES work is the Rice 6.1.1 "beta 6" plugin with the settings listed below; it will have some glitches such as being able to see the inside of the face of a character when using the game's manual aim mode and text will not be as crisp, plus there will be stray lines around text and the edge of the screen during boss fights; however, the plugin makes implementing hacks playable during bosses and can always be swapped back out for Jabo's plugin, which works much better for the rest of the game.

Note that to change some of these settings you will need to uncheck "Hide Advanced Options", click "OK" and then re-open the plugin settings.

The aforementioned settings:

Frame update at: Should be negligible, but "At VI origin update" works
N64 Frame Buffer: "Basic Framebuffer" works; "Basic & Write Back" seems to work too but is not recommended
Rendering To Texture: "Basic Render-to-texture"; most other options cause shadows to not render correctly
Normal Blender: "Half" checked, in other words a square rather than a check or unchecked box
Fine Texture Mapping: See previous
Normal Combiner: See previous
Fast Texture: See previous
Force Buffer Clear: OFF
Disable Blender: OFF
Emulate Clear: OFF
Force Depth Compare: OFF; the previous 3 options and this one appear to cause problems if set to anything else
The following options seem to have little apparent effect if any:
Disable Big Textures, Disable Culling, Texture Scale Hack, Faster Loading Tiles, Texture 1 Hack, Primary Depth Hack, Increase TextRect Edge, Near Plane Z Hack, Try to Use Smaller Texture (faster), Alternative texture size calculation, Enable Texture LOD
I tend to leave the previous items off with TMEM Emulation checked; leave N64 Screen Width/Height empty with Use CI Width and Ratio set to "No" to avoid complicating the resolution.

~~~~~

Jabo's D3D8 version 1.6 plugin can work as well by enabling the option "Copy framebuffer to RDRAM". Enabling "Super2xSal textures" tends to look nicer as well.

You will need to uncheck "Hide Advanced Settings" and click Apply to be sure to see certain options.

~~~~~

Note that using the above mentioned plugins with the above mentioned settings will sort out issues with bosses, but only Rice 6.1.1 will work in Lupus's night vision part of the game.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

To quickly use the trainer, copy the binaries (with the extension .dmp) to the addresses they are named after.

For example: the data in "Trainer - 01FFE000.dmp" would be copied to the address 0x01FFE000 in the ROM.

When you've done this, edit the cheats in the "Cheat List - 01FFF000.txt" file following the specifications in the "Code Type Spec.txt" file.

Use "Test Cheat List.txt" or the unmodified "Cheat List - 01FFF000.txt" files for examples of cheat lists.

Assemble the cheat list (I use the MIPS port of GNU AS) and paste the assembled binary at the address 0x01FFF000 in the ROM.

The ROM should execute as normal but with your cheats implemented~

IMPORTANT: To get around crashes, the trainer is loaded into the upper 4 megabytes of memory. The expansion pak/8 megabytes of RAM options will need to be enabled in emulators for the hack to work (and an expansion pak will be required for the hack to work on the actual hardware if it even can).

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Currently, the "Cheat List - 01FFF000.txt" contains example cheats from a hack I am working on that is located in the included "Co-Op Hack" folder in the parent directory of this file's directory.

This will hopefully be helpful as an example of how to use the trainer and what it is capable of.

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

About assembling the trainer:

The code has been rewritten to be more easily relocatable. "TRAINER_OFFSET" is a macro defined in associated files that may simply be changed to the desired RAM offset in each to make the hack assemble correctly for loading to that address, though checksums will need to be recalculated if and when the trainer load code is modified.

Similar can be said about "INJECTOR_OFFSET", which is a macro for the location of code used to hook the trainer. This address must be different; note that the trainer is currently designed to use 8 kilobytes of memory.

The "INJECTOR_OFFSET" macro is not actually used in the current version of the source and is part of the failed attempt at writing a version of the trainer which didn't require checksum recalculation.
