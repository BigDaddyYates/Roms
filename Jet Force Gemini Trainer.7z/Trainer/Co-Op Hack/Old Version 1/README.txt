This folder contains outdated code from the first debugging phase.
