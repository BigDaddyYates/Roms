If you just want to use the hack, see the "Patch and How to Use" folder.

~~~~~

This is a hack which crudely adds support for playing the game's single player mode with multiple players, up to FOUR (originally only two could play) as well as allowing other players to play as ANY character which can be selected in multiplayer mode (Floyd will be able to be chosen through the regular co-op menu choice when entering the game through single player; co-op for this hack is entered through the multiplayer mode).

The hack works by reprogramming the game to allow save loading through interfacing with the controller (in ways specified in the hack's documentation in the "Patch and How to Use" folder), after which the loaded game will be able to be saved normally as a result of another assembly hack which will constantly copy data from the multiplayer mode's addresses to the memory range which is saved by the game during normal saving (which is possible by forcing the single player menu in multiplayer if and only if a save is loaded).

There is a GameShark version of this hack included for comparing and contrasting between code usage and trainer usage that works well in PJ 64, but as this is a ROM hack it is more promising. Help with debugging (especially for getting online play working more reliably and/or with higher quality) would be appreciated.

~~~~~

This hack was created using a trainer I wrote. That project can be found either here:

http://dl.dropbox.com/u/336940/Hextator%27s%20Doc.7z

in the folder

Hextator's Doc/Media/Games/Console/Nintendo 64/Assorted/Jet Force Gemini/Trainer"

or here:

http://www.romhacking.net/hacks/711/

The "source" files for this project must be used as codes for the trainer (they are in the "Source" folder). Note that the Rainbow Blood cheat is included in this hack as a bonus.

~~~~~

The "Notes" folder contains information I used to help me make the hack and is useless for people who aren't working on improving the hack who are just using it.
