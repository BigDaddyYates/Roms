~~~ Trainer Issue ~~~

Please read the file "[root folder of the trainer]/Source/README.txt" for information on issues graphics plugins for emulators will have with this hack and how to resolve them.

~~~~~

The single player mode won't have any issues.
If you're tired of issues, play through the problem area in single player and go back to co-op for another level.
Keep in mind that if you save from the pause menu in single player, you can use the L button in co-op to warp all the way back to that exact room with the tribals you saved and killed at the time of saving restored to those states, allowing you to do as little as necessary in single player to return to playing co-op without issues.

Below is a list of issues encountered from playing through much of the game with this hack and some information on how to get around some of the problems.

The hack is fully playable; the issues below interfere with the ability to play it but do not make it unable to be completed as long as you watch out for and avoid these problems.

~~~ Issues/Bugs and how to deal with them ~~~

- The other "README" file notes problems may occur if L is pressed at a bad time before warping to the campaign levels.
	Keep the instructions in that file in mind.

- If you don't play through the game up until Juno arrives on Goldwood the first time and then save you will have difficulty choosing his levels for playing in co-op.

- Plugins for emulators will not recognize the game due to the trainer modifying the game's checksums, causing bosses and Lupus's night vision area to make it impossible for player 1 to see during play, even in single player mode, unless the issue is resolved by following the instructions at the top of this file.
	Choose a better plugin/better settings for your plugin (as described above).
	Alternatively you can play the unhacked version of the game or hack the emulator and/or graphics plugin of your choice, but why go out of your way? (I've actually hacked the graphics plugin to get it working correctly but it is difficult and unnecessary to reproduce)
	Lupus's night vision area won't have this problem in co-op; you should be able to play with Lupus in co-op if you do his part of Mizar's Palace first (see below for why it must be done first or second and not last) to get past that part of the game in co-op without any need to use the recommended Rice plugin (Jabo is better for everything else anyway).

- Rooms in Sekhmet crash if Juno enters them in co-op.
	These rooms are reached by going through the door on the left from the landing pad.
	The lava room can be reached by going right from the landing pad if the green key has already been obtained, skipping the problem rooms so that Juno can enter the lava.

- Similar occurs with Lupus in Goldwood areas.
	The Rim will have to be unlocked and cleared in single player mode or you will need to get to the Rim with Lupus in single player, save, then suicide bomb to get to the other sides of gaps otherwise unable to be crossed as you progress through it in co-op.
	You can also jump off of the map until you appear by the door that leads to the Rim to begin with, effectively bypassing the need to use Lupus entirely.

- Also because of Lupus's problems, if Lupus is last to enter Mizar's Palace when the characters are to meet the first time, he must do so in single player so that the first Mizar can be defeated in single player.
	If he is not last, another player (Vela) can enter last and, in co-op, because players keep who they choose, they will not be forced to use Lupus to fight the first Mizar and can choose less glitchier characters (like one of the Vela characters).
	Lupus can be brought to his part of Mizar's Palace up to the part where the characters meet the first time without any problems in co-op; it's the boss fight that is the problem.

- In general, Lupus and Juno cause crashes in lots of places (they both cause crashes in Walkway even, so after warping to Walkway use the pause menu to pick a different level a soon as possible).

- The last player (for example, player 2 in 2 player co-op) seems to be the only player who can control the pause menu.
	Oddly enough only the first player seems to be able to control the options menu within the pause menu (second item from the top on the left side of the pause menu) and in this case only player 1 can use that menu.
	While playing online as player 2 I saw that player 1 had control of the map menu that appeared after completing a level.
	In any case it's a good idea to try moving around on the menu for each player before assuming the game has crashed; if it had crashed the animations would pause anyway.

- Eschebone and (rarely) other levels apparently screw up sometimes (I've gone through with no problems more than once, but not always) in later areas and causes the hack to malfunction such that pressing L no longer warps players together.
	It instead causes the L button to work the way it does when it first loads the save after which pressing it again will warp the players to the Walkway, interrupting progress.
	When nearing the room with the magenta key, stop using the L button and save after getting anything from a chest in case the game crashes or, if the save is loaded by accident, reset the game to keep what you got before.
	You can test whether it is safe to use the L button by checking if the pause menu is working correctly; this should be done often near the magenta key.

- If you get the tri-rockets and/or play with Juno as the first player, you can play up to the door that leads to the Castle area in Tawfret.
	To get past the door to play through the Castle in co-op however, you will need to play up to past that door in single player and then save.
	Juno doesn't seem to cause any issues in Tawfret, at least up to the Castle (it hasn't been tested if he can play through it although he probably can; Vela works fine).

- While playing online, desync can be a real pain and cause progress to be lost if you don't save in time.
	Levels are unlocked the moment you enter the room where your ship is ready to take off.
	If you see your ship, consider saving; entering the next level may cause desync but if you save then you can always pick up where you left off.
	However the game DOES automatically save when completing a level sometimes, and due to the level unlocking mentioned above this means levels are correctly unlocked automatically, potentially saving you some grief (this has actually happened to me in an online play).

- Throwing grenades or spawning objects in general in the Spacestation level can cause crashes due to object overload.
	They can happen anyway if you enter too many rooms without collecting/killing the objects you pass by.
	This happens mostly (only?) in the first basement floor (the floor reached by taking the first elevator in front of your ship).
	Focus on quickly killing as many enemies as possible with bullet or missile weapons before throwing things.
	After taking the first elevator down there are a couple of tribals which can be reached by dropping down to the lower half of that floor immediately.
	Kill or save them as quickly as possible to reduce the number of objects and enter a different room if the pause menu disables due to memory starvation.

- Entering Rith Essa and Water Ruin seems to be difficult (normally, choosing the former warps players to Spawnship instead, the latter will cause players to spawn on top of the ship if L is not held when entering, ending the level early).
	Entering Tawfret's Castle area doesn't seem to directly be possible in co-op.
	Saving in single player with one character at the beginning of Tawfret's Castle area, with another character at the beginning of Water Ruin and the last character at the beginning of Rith Essa will alleviate this problem.
	After saving in these locations with a character, choose that character from the character select menu in the pause menu while playing co-op and then choose the level they were saved at to go to it correctly.
	Saving at Tawfret's Castle with Juno, with Lupus at Rith Essa and with Vela at the Water Ruin in single player makes co-op much more convenient and playable.
	Information on how to deal with difficulties with entering other places follows:

~~~~~

If entering a room or level causes the other players to spawn such that the room or level is exited immediately (one such place exists in Sekhmet, although the circular nature of the level means it's not an issue to begin with) as it is entered, try holding L and forward when entering, then moving in a circle after entering the level or room until the other players have finished warping to the first player.
Let go of and begin tapping L if the screen stays black, although you shouldn't need to (in older versions of the hack this was true, it should no longer be however).

The Water Ruin level is a good example of when you will need to hold L and forward, then move in a circle to enter the level without the other players, who spawn on top of the ship, causing the level to end.

In the particular case of the Water Ruin, if it is the last place a character has saved in the single player mode of the game, selecting that character in the single player pause menu's character select or with C Left/Right in the map menu before selecting the Water Ruin should bypass the spawning issues altogether.

Also note that sometimes other players will spawn in places which won't cause players to return to the previous room accidentally unless they move, in which case sometimes pressing L to warp them is a bad idea and leaving them aside to clear the room solo may be required of player 1 to get past such rooms.
	The only room I've encountered like this was in Goldwood's Lodge.
	In that room you spawn on the wrong side of the door and can walk backward into the remnants of the part of the level you came from which won't be loaded entirely, allowing you to jump off the map and respawn in a better location.

~~~~~

- Dying won't end the game, at least not if you pick slaughter mode from the multiplayer options (recommended).
	Die a much as you like, even against bosses.
	This can even be used to warp to the other sides of rooms by suicide bombing or jumping off of the level.

- Bosses can be fought in co-op but it can be glitchy.
	If a player dies once they will be unable to move.
	If they die twice they will be able to start playing again but will not have any movement restrictions.
	Saving as soon as possible after defeating a boss is a good idea though the only issue should be the spawn locations of the other players which can be fixed by using the L button.

- Walkway can be cleared in co-op; however, exiting the sewers will cause the other players to spawn inside the trap door, trapping all players in the sewers - to get around this, hold L when exiting the trap door and keep it held until the room is exited.

- Players don't always spawn together; holding L when entering an area or jumping and then holding it while playing normally should synchronize player positions to fix most issues.

- Co-op can crash in many places, lots of which can be averted by playing through the offending area in single player mode or in co-op with all players as Vela (if it can be reached).
	Most if not all of crashes seem to involve players choosing to play as Lupus or Juno...as Walkway is the "lobby" for this hack and one such place where those characters cause problems, the game should be paused and another level selected immediately if they are to be used.

- Characters selected in multiplayer which aren't Vela, Juno or Lupus will turn into Vela, Juno or Lupus depending on which of those characters they are "based" on (which can usually be guessed by who shares a voice actor) and tend to crash the game almost immediately; they should not be used.

- Survival mode causes more crashes than usual; timed mode and slaughter mode work fine (race mode does too but you can't actually play the game in race mode; only drive around silly).

- Menus don't display correctly (because of split screen) but are fully functional and visible enough to be used with ease, at least by players who have played before.
	Alternatively they are much easier to see with 3 or 4 player split screen and the horizontal split screen for 2 players; alternating between vertical and horizontal split screen may help.

- It is possible to save in co-op after transforming a character such as Vela into a tribal or ant character.
	If this becomes a problem, although it probably won't, loading the save in single player and saving after choosing a level to go to from the pause menu will change the character back.

~~~ Keys ~~~

- All keys can be obtained by playing through co-op with players playing as Vela (with or without a jet pack); however Eschebone's strangeness means that getting the blue key or even the magenta key from this level in co-op (not to mention playing through it) can be a pain.

- Regarding the blue key when getting it from Sekhmet:
	Sekhmet seems to crash if Juno is selected as one of the characters when taking the normal route.
	However progressing through Sekhmet by going right through the green key door from the landing pad will eventually lead to the lava room where Juno can then get to the room with the blue key.

- Getting the magazine (or nearby blue key) for trading for the mine key seems to disable the menu sometimes.
	If this happens, exiting the room should bring it back so it can be saved.
