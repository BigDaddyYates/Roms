/**
 * JFG_Co_Op_Save_Embedder by Hextator
 * Public domain
 * Embeds a save into a co-op hacked JFG ROM for online play purposes
**/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.security.MessageDigest;
import java.text.NumberFormat;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class JFG_Co_Op_Save_Embedder {
	// Constants

	// Code list address
	public static final int codeListAddress = 0x01FFF000;
	public static final int correctLength = 0x02000000;
	public static final byte[] hackedMD5 = new byte[] {
		/**
		 * Previous stable MD5
		(byte)0xC6, (byte)0xBB, (byte)0x63, (byte)0x49,
		(byte)0x3A, (byte)0xBF, (byte)0xDE, (byte)0x50,
		(byte)0xB9, (byte)0xFE, (byte)0x9D, (byte)0x4D,
		(byte)0x92, (byte)0x9F, (byte)0x44, (byte)0x3F
		**/
		(byte)0xDC, (byte)0xA1, (byte)0x9E, (byte)0x0E,
		(byte)0x18, (byte)0x84, (byte)0x53, (byte)0xBB,
		(byte)0x16, (byte)0xE5, (byte)0x51, (byte)0x0C,
		(byte)0x77, (byte)0x7C, (byte)0x53, (byte)0x53
	};
	// Signature indicating instructons to NOP
	public static final byte[] deadcode = new byte[] {
		(byte)0xDE, (byte)0xAD, (byte)0xC0, (byte)0xDE
	};
	// The instructions which are being replaced; they
	// will be put back for MD5 checksum purposes and
	// removed after
	public static final byte[] instructions = new byte[] {
		(byte)0xAE, (byte)0x11, (byte)0x00, (byte)0x00,
		(byte)0xAE, (byte)0x12, (byte)0x00, (byte)0x04,
		(byte)0xAE, (byte)0x13, (byte)0x00, (byte)0x0C
	};
	// The NOPs to write
	public static final byte[] NOPs = new byte[instructions.length];
	// The data that is usually at the end of the file;
	// it will be put back for MD5 checksum purposes and
	// removed after
	public static final int saveLength = 0x538;
	public static final int saveLengthInFlash = 0x4000;

	// General utility functions

	// XXX Refactor into library

	public static boolean DEBUG = false;

	private static void log(String message) {
		if (DEBUG) System.out.println(message);
	}

	public static int parseInt(String input) {
		input = input.trim();
		int base = 10;
		if (input.indexOf("0x") == 0) {
			base = 16;
			input = input.substring(2);
		}

		return Integer.parseInt(input, base);
	}

	public static int __argIndex = 0;

	public static abstract class FetchArgument {
		public abstract Object fetch(String description);
	}

	public static abstract class StringArgConverter {
		public abstract Object convert(String input);
	}

	public static abstract class NumberGetter {
		public abstract Number get(String desc);
	}

	public static abstract class NumberVerifier {
		public abstract boolean verify(Number input);
	}

	public static Object initializeFromArgument(
		String[] args, int index,
		FetchArgument fetch, String description,
		StringArgConverter converter
	) {
		__argIndex = index + 1;
		Object output = null;
		String obtained = null;
		try {
			obtained = args[index];
		} catch (Exception ex) { }
		if (obtained != null && !obtained.isEmpty()) {
			output = converter.convert(obtained);
		}
		if (output == null)
			output = fetch.fetch(description);
		return output;
	}

	public static Object initializeFromArgument(
		String[] args,
		FetchArgument fetch, String description,
		StringArgConverter converter
	) {
		return initializeFromArgument(
			args, __argIndex,
			fetch, description,
			converter
		);
	}

	private static File fileHelper(String title, int mode) {
		java.awt.FileDialog chooser = new java.awt.FileDialog(
			new java.awt.Frame(), title, mode
		);
		chooser.setVisible(true);
		chooser.setLocationRelativeTo(null);

		String directory = chooser.getDirectory();
		String file = chooser.getFile();

		if (directory == null || file == null) { return null; }
		return new File(directory + file);
	}

	public static File showOpenFileDialog(String what) {
		return fileHelper(
			"Select " + what + " for opening",
			java.awt.FileDialog.LOAD
		);
	}

	public static File showSaveFileDialog(String what) {
		return fileHelper(
			"Select path to save " + what,
			java.awt.FileDialog.SAVE
		);
	}

	public static byte[] readAllBytes(File file) {
		byte[] fileData;
		FileInputStream fileInputStream = null;
		fileData = new byte[(int)file.length()];
		try {
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(fileData);
		} catch (Exception e) {}
		try { fileInputStream.close(); } catch (Exception e) {}
		return fileData;
	}

	public static byte[] getFileData(String description) {
		File file = showOpenFileDialog(description);
		return readAllBytes(file);
	}

	public static void writeAllBytes(File outputDest, byte[] output) {
		FileOutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(outputDest);
			outputStream.write(output);
		} catch (Exception e) {}
		try { outputStream.close(); } catch (Exception e) {}
	}

	public static void putFileData(String description, byte[] output) {
		File outputDest = showSaveFileDialog(description);
		writeAllBytes(outputDest, output);
	}

	public static byte[] fileGetter(
		String[] args, int index, String desc
	) {
		return (byte[])initializeFromArgument(
			args, index,
			new FetchArgument() {
				@Override
				public Object fetch(String description) {
					return getFileData(description);
				}
			},
			desc,
			new StringArgConverter() {
				@Override
				public Object convert(String input) {
					return readAllBytes(new File(input));
				}
			}
		);
	}

	public static byte[] fileGetter(
		String[] args, String desc
	) {
		return fileGetter(args, __argIndex, desc);
	}

	public static void fileSaver(
		String[] args, int index, String desc, final byte[] outputData
	) {
		initializeFromArgument(
			args, index,
			new FetchArgument() {
				@Override
				public Object fetch(String description) {
					putFileData(description, outputData);
					return true;
				}
			},
			desc,
			new StringArgConverter() {
				@Override
				public Object convert(String input) {
					writeAllBytes(new File(input), outputData);
					return true;
				}
			}
		);
	}

	public static void fileSaver(
		String[] args, String desc, final byte[] outputData
	) {
		fileSaver(args, __argIndex, desc, outputData);
	}

	private static int pollForInt(String message) {
		int output;
		while (true) {
			try {
				output = parseInt(javax.swing.JOptionPane.showInputDialog(
					message
				));
			} catch (Exception e) { continue; }
			break;
		}
		return output;
	}

	public static Number getNumber(
		String[] args,
		final NumberGetter getter, final NumberVerifier ver,
		String desc
	) {
		return (Number)initializeFromArgument(
			args,
			new FetchArgument() {
				@Override
				public Object fetch(String description) {
					Number saveToUse = getter.get(description);
					if (!ver.verify(saveToUse)) {
						return null;
					}
					return saveToUse;
				}
			},
			desc,
			new StringArgConverter() {
				@Override
				public Object convert(String input) {
					try {
						return NumberFormat.getInstance().parse(input);
					} catch (Exception ex) { }
					return null;
				}
			}
		);
	}

	public static String byteArrayToString(byte[] input) {
		if (input == null || input.length == 0)
			return null;

		String outputString = "";
		for (int i = 0; i < input.length; i++)
			outputString += String.format("%02X ", input[i] & 0xFF);
		return outputString.substring(0, outputString.length() - 1);
	}

	// Use this to make drivers
	private static abstract class Run {
		public abstract void execute(String[] args);
	}

	// Methods for program logic

	// 8 bit swap
	public static byte[] eightSwap(byte[] input) {
		for (int i = 0; i < input.length; i += 2) {
			byte byte1 = input[i];
			input[i] = input[i + 1];
			input[i + 1] = byte1;
		}
		return input;
	}

	// 16 bit swap
	public static byte[] sixteenSwap(byte[] input) {
		for (int i = 0; i < input.length; i += 4) {
			byte byte1 = input[i];
			byte byte2 = input[i + 1];
			input[i] = input[i + 2];
			input[i + 1] = input[i + 3];
			input[i + 2] = byte1;
			input[i + 3] = byte2;
		}
		return input;
	}

	// Drivers

	// Tested and working
	private static class Patcher extends Run {
		private static String OFFLINE_STR = "Jet Force Gemini (Co-Op)";
		private static String ONLINE_STR = "Jet Force Gemini (Co-Op/online ready)";

		private String openDesc = OFFLINE_STR;
		private String saveDesc = ONLINE_STR;
		private boolean unpatch = false;

		public Patcher() { }

		public Patcher(boolean unpatch) {
			this.unpatch = unpatch;
		}

		public void execute(String[] args) {
			// Actual program logic
			if (unpatch) {
				openDesc = ONLINE_STR;
				saveDesc = OFFLINE_STR;
			}
			byte[] file = fileGetter(args, openDesc);
			byte[] save = null;
			if (!unpatch) {
				save = fileGetter(args, "Jet Force Gemini save (.fla)");
			}
			byte[] uninitialized = new byte[saveLength];
			java.util.Arrays.fill(uninitialized, (byte)0xFF);
			if (file.length != correctLength)
				throw new RuntimeException("That file has incorrect length!");
			// Initialize address to "not found" value
			int address = -1;
			// Data to check
			byte[] data = new byte[deadcode.length + instructions.length];
			// normalSignature = deadcode concatenated with instructions
			System.arraycopy(deadcode, 0, data, 0, deadcode.length);
			System.arraycopy(instructions, 0, data, deadcode.length, instructions.length);
			final byte[] normalSignature = java.util.Arrays.copyOf(data, data.length);
			// nopSignature = deadcode concatenated with NOP instructions
			System.arraycopy(deadcode, 0, data, 0, deadcode.length);
			System.arraycopy(NOPs, 0, data, deadcode.length, NOPs.length);
			final byte[] nopSignature = java.util.Arrays.copyOf(data, data.length);
			// Search for either signature
			// and set address to where the instructions are found
			for (int i = 0; codeListAddress + i <= file.length - normalSignature.length; i += 4) {
				try {
					System.arraycopy(file, codeListAddress + i, data, 0, data.length);
				} catch (Exception ex) { throw new RuntimeException("" + i); }
				if (
					java.util.Arrays.equals(data, normalSignature)
					|| java.util.Arrays.equals(data, nopSignature)
				) {
					// We found the signature; exit this loop
					address = codeListAddress + i + deadcode.length;
					break;
				}
			}
			if (address == -1)
				throw new RuntimeException(
					"DEADC0DE signature not found; " +
					"something is corrupt " +
					"or you're using the wrong file"
				);
			// Put the instructions back
			System.arraycopy(instructions, 0, file, address, instructions.length);
			// Put the uninitialized data back
			System.arraycopy(
				uninitialized, 0,
				file, file.length - uninitialized.length,
				uninitialized.length
			);
			// Check the MD5
			MessageDigest md = null;
			try {
				md = MessageDigest.getInstance("MD5");
			} catch (Exception ex) { return; }
			byte[] md5 = md.digest(file);
			if (!java.util.Arrays.equals(md5, hackedMD5))
				throw new RuntimeException(
					"MD5 mismatch; something is corrupt " +
					"or you're using the wrong file"
				);
			if (!unpatch) {
				// NOP the relevant instructions again
				System.arraycopy(NOPs, 0, file, address, NOPs.length);
				Number result = getNumber(
					args,
					new NumberGetter() {
						@Override
						public Number get(String desc) {
							return pollForInt(desc);
						}
					},
					new NumberVerifier() {
						@Override
						public boolean verify(Number input) {
							return (input.intValue() >= 1 && input.intValue() <= 6);
						}
					},
					"Give the number of the save you want to use from 1 through 6."
				);
				Integer saveNumber = result == null? null : result.intValue() - 1;
				if (saveNumber == null) {
					throw new RuntimeException("I said ONE TO SIX. ARGH.");
				}
				int saveToUse = saveNumber;
				byte[] loadedSave = new byte[saveLength];
				try {
					System.arraycopy(
						save, saveToUse * saveLengthInFlash,
						loadedSave, 0,
						saveLength
					);
				} catch (Exception ex) {
					throw new RuntimeException(
						"Your save appears to be the wrong size. " +
						"Maybe you picked the wrong file?"
					);
				}
				// Convert little endian save to big endian save
				loadedSave = sixteenSwap(eightSwap(loadedSave));
				if ((byte)saveToUse != loadedSave[3])
					throw new RuntimeException(String.format(
						"According to your save, save %d is marked as save %d.\n" +
						"You probably picked the wrong file so we're aborting.",
						saveToUse + 1, loadedSave[3] + 1
					));
				// Put save where it needs to be
				System.arraycopy(loadedSave, 0, file, file.length - saveLength, saveLength);
			}
			fileSaver(args, saveDesc, file);
		}
	}

	// Change this and build again to use a different tool,
	// or change it programmatically before calling run.execute(args)
	// to simulate multiple utilities
	private static Run run = new Patcher();

	// Main

	private static boolean userWantsUnpatch(String[] args) {
		return (Boolean)initializeFromArgument(
			args,
			new FetchArgument() {
				@Override
				public Object fetch(String description) {
					final int option = JOptionPane.showConfirmDialog(
						null,
						description,
						"JFG Co-Op Online Enable Hack",
						JOptionPane.YES_NO_OPTION
					);
					return option == JOptionPane.NO_OPTION;
				}	
			},
			"Are you applying the online hack instead of undoing it?",
			new StringArgConverter() {
				@Override
				public Object convert(String input) {
					return input.equals("UNPATCH");
				}
			}
		);
	}

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(
				UIManager.getSystemLookAndFeelClassName()
			);
			if (userWantsUnpatch(args)) {
				run = new Patcher(true);
			}
			run.execute(args);
		} catch (Exception e) {
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			JTextArea errorDisplayArea = new JTextArea(
				"Exception: " +
				e.getMessage() +
				"\n" +
				result.toString()
			);
			JScrollPane errorPane = new JScrollPane(errorDisplayArea);
			JOptionPane.showMessageDialog(
				null,
				errorPane,
				"Error",
				JOptionPane.ERROR_MESSAGE
			);
		}
		System.exit(0);
	}
}
