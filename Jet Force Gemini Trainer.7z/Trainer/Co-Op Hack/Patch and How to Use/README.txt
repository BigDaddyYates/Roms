IMPORTANT NOTE: This README assumes that you are working with the .z64 (big endian) version of the ROM. If you aren't, convert it.

~~~~~

NOTE: "Co-op" refers to use of this hack, not the boring default co-op the game has built-in (unless otherwise noted).

Apply the UPS patch given to a clean JFG (U) ROM using tsukuyomi or NUPS (by Nintenlord; it tends to be more reliable though using the JFP is recommended)
- OR -
Apply the JFP patch given to a clean JFG (U) ROM using:

Hextator's Doc/Development/Apps/Patching/JFP Format/Java Implementation/JFP.class

(which can be executed on a Windows platform with a properly configured Java Runtime Environment by executing "Drive.bat" in the same folder).

Hextator's Doc can be found at:

http://dl.dropbox.com/u/336940/Hextator%27s%20Doc.7z

Alternatively you can get the JFP patcher from here:

http://www.romhacking.net/utils/767/

~~~~~

The original ROM MD5 should be

772CC6EAB2620D2D3CDC17BBC26C4F68

with CRCs

0x8A6009B6 and 0x94ACE150 at addresses 0x10 and 0x14 respectively (in other words, INI code "8A6009B6-94ACE150-C45").

The modified ROM MD5 should be

DCA19E0E188453BB16E5510C777C5353

with CRCs

0x16CCD7E9 and 0x94779E23 at addresses 0x10 and 0x14 respectively (in other words, INI code "16CCD7E9-94779E23-C45").

This information can be checked with Mupen64++ Beta 0.1.3.12.

~~~~~

Use these settings for the ROM (names of options taken from Project 64 v 1.6):

CPU core style: Recompiler
Self-modifying code Method: Check Memory & Cache
Memory Size: 8 MB - 4 MB will crash
Advanced Block Linking: Default
Default Save type: Use First Used Save Type
Counter Factor: 2
Large Compile Buffer: OFF
Use TLB: OFF
Register Caching: OFF; this has to be off for the trainer to work anyway.
SP Hack: OFF
RSP Audio Signal: OFF

~~~~~

In the actual game, go to multiplayer mode and choose the settings like normal but

DO NOT choose Survival mode or the target practice mode.

The former causes the game to crash and the latter won't allow you to play.

The race mode option will not allow you to do anything but drive around, which is fun but you will not be able to actually make any progress.

Without the screen splitting being done properly, you may notice the screen is already split, fudging up the menus. They should still be fairly usable.

Once in the multiplayer game, press L to load your save. This only works once; if you want to do this again you will need to reset the game first.

Currently only the first save slot is used. The first save slot will be used for saving during gameplay as well. This may be modified in the future to allow selection of the save to use based on, for example, the ammunition you have in your pistol.

Vela's data will go to player 1.
Juno's data will go to player 2.
Lupus's data will go to player 3.
Player 4 will start with nothing and anything they collect will not be usable in single player mode.

Press L once more to warp to the Walkway level, giving access to the single player menu when pausing and allowing normal play of the single player mode...with more than one player!

Note that after loading your file but before warping, you might want to stock up on some free weapons from the multiplayer level you chose to start in. ;D

After warping to the Walkway level, the L button can be used to warp other players to player 1.

Alternatively, if your last save was from the pause menu and even if the saving was done in single player, pressing L will warp you back to the exact room you saved with all of the tribals you had saved and killed restored to those states.

After that L will return to warping other players to player 1's position.

If you do not wish to warp again with L after reaching the Walkway to restore the room and tribal data of where you last saved, press any button other than L such as R and then pressing L will only be used for warping players to player 1 from then until you next load a save in co-op.

Only use the control stick to move if holding L as pressing other buttons while pressing L will cause position synchronization to be disabled (this is to avoid players accidentally bumping the L button when they don't want to).

Note that the L button only performs the above actions when pressed by player 1.

Also note that pressing L at a bad time (in other words, too early, before getting into a multiplayer game) may cause crashes or undesired behavior although it won't cause any permanent damage to saves unless you actually choose to save via the menu.

Pressing L while in the pause menu before warping (and possibly after, although it shouldn't matter then) may cause the game to freeze since warping in the pause menu isn't a good idea even in the unhacked version of the game; however the hack has recently been modified to attempt to detect when this occurs and disallow warping appropriately.

Finally, because of how the warping is done, tribal data will not be successfully saved when a level is completed unless you do these two things (in any order):

- Save (or perhaps kill) at least one tribal in the region (this is important if you've warped once more from the Walkway region to restore the room and tribal data of a previous save)

- Enter another room in the are to trigger the display of the area's name.
	For example, if you saved at the Gem Quarry and pressed L until you were returned to there after loading your save you should save a tribal and enter a hut, not necessarily in that order, to cause reaching your ship to correctly update your "high score" for the tribal saving.

~~~ Notes ~~~

- Works in Mupen64++ Beta 0.1.3.12 but only works in PJ 64 1.6 if register caching is disabled (and it will not work with the interpreter core); see above

- Works in Nemu if nemu64.ini is appropriately modified; use these settings:

[Jet Force Gemini]
FriendlyName=Jet Force Gemini
CompilerMode=3
EEPRomsize=2048
Comment=T | Fully Playable - Uses FB

- Other players are targeted by the auto aim in co-op mode just as they are in multiplayer (perhaps this is an interesting handicap)

- Floyd pads do not work in this version of co-op (though you can always use them in regular co-op or single player; keep in mind that only Juno can use the Floyd pad in Mizar's Palace)

- Loading save data causes desynchronization online in Mupen over Kaillera; for information on how to circumvent this refer to "Instructions for Playing Online.txt".
	If you do follow those instructions, you get something like this:
	http://www.justin.tv/hextator/b/282063403
	The above links to a video of the hack being played with a friend online, demonstrating our ability to save our progress and reload it later in the event of a crash or desync.
	In our case, I accidentally bump a button on my controller that closes the ROM somewhere in the video, which is a dumb but very possible way to demonstrate why saving often is important.
	More videos for the playthrough are linked to in the "Online Playthrough.txt" file as further demonstration of what the hack is capable of. At the moment the playthrough is ongoing/incomplete (the hack however is very much complete).
