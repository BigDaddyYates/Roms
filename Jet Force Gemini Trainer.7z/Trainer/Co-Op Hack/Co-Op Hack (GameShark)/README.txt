These codes are for a JFG ROM with MD5

772CC6EAB2620D2D3CDC17BBC26C4F68

And CRCs

0x8A6009B6 and 0x94ACE150

In the actual game, go to single player mode and erase the file you want to save to in co-op mode if it's not empty already.

Copy the file you want to load to the location you just cleared and press L when this is done. You may be able to get away with simply hitting L or erasing a blank file without copying another to start with a blank file in co-op, but it's best to have a file saved past the annoying tutorial if you want to start a new file.

Go to multiplayer mode and choose the settings like normal. Without the screen splitting being done properly, you may notice the screen is already split, fudging up the menu. It should still be fairly usable.

Once in the multiplayer game, press L to load your file the rest of the way.

Note that the L button only performs the above actions when pressed by player 1.

Vela's data will go to player 1.
Juno's data will go to player 2.
Lupus's data will go to player 3.
Player 4 will start with nothing and anything they collect will not be usable in single player mode.

Note that you have access to the single player menu when pausing and allowing normal play of the single player mode...with more than one player! But after loading your file and before warping, you might want to stock up on some free weapons from the multiplayer level. ;D
