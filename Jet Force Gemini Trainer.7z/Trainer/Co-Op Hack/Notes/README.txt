This folder contains information that was used to help make this hack.
