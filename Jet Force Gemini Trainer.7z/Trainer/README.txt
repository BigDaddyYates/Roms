Please see the "Source" folder for more information and...well, the source.

This folder is mostly just notes used to help create the trainer and other things which didn't quite turn out to be useful.

~~~~~

The following information details what version of Jet Force Gemini this hack is for.

The ROM should be the non-kiosk (U) version in the .z64 format.

~~~~~

An application for converting the ROM to the .z64 format is in the "Z64" folder.

It is a Java application, so read this and/or use "Drive.bat" to figure out how to run the application:

http://www.cs.swarthmore.edu/~newhall/unixhelp/debuggingtips_Java.html#compiling

You may have problems with your "path" such that running "Drive.bat" reports that "java.exe" can't be found.

If this happens, find "java.exe" in the bin folder of your Java Runtime Environment and add the path to that folder to your system path; here is how:

1. From the desktop, right-click My Computer and click Properties.
2. In the System Properties window, click on the Advanced tab.
3. In the Advanced section, click the Environment Variables button.
4. Finally, in the Environment Variables window, highlight the Path variable in the Systems Variable section and click the Edit button. Add or modify the path lines with the paths you wish the computer to access. Each different directory is separated with a semicolon as shown below.

C:\Program Files;C:\Winnt;C:\Winnt\System32

So for example you would change the above to "C:\Program Files;C:\Winnt;C:\Winnt\System32;C:\Program Files\Java\jre6\bin;" if that was where java.exe was for you (obviously you will need to install the latest version of Java if you haven't already).

~~~~~

The ROM should have the following stats (the program in the "Z64" folder will confirm these for you):

The original ROM MD5 should be

772CC6EAB2620D2D3CDC17BBC26C4F68

with CRCs

0x8A6009B6 and 0x94ACE150 at addresses 0x10 and 0x14 respectively (in other words, INI code "8A6009B6-94ACE150-C45").

This information can be checked with Mupen64++ Beta 0.1.3.12.

~~~~~

In the "Codes" folder, "Assorted Codes.txt" is a file containing some example codes converted from GameShark format to the trainer's format.

~~~~~

The "Auto" folder contains a small utility written in Java to help with generating scripts (currently only for Windows users) to automate the usage of the other Java utilities related to this trainer and the example hack included with it.

Those utilities are the converter from a clean JFG ROM to a clean Z64 JFG ROM, the JFP patcher (distributed separately), and the Online Hack Enabler (previously found at this path:

"/Co-Op Hack/Patch and How to Use/Online Hack"

though it has since been deprecated and is probably not useful).

It is recommended that the utility in the "Auto" folder be ran first after reading the various README files herein to understand what it is prompting for, after which future patching and unpatching of the trainer/example hack will be much quicker (on Windows, anyway).
