/**
 * JFG_to_Z64 by Hextator
 * Public domain
 * Reformats Jet Force Gemini to be big endian
**/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.security.MessageDigest;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class JFG_to_Z64 {
	// Constants

	public static final int correctLength = 0x02000000;
	public static final byte[] correctMD5 = new byte[] {
		(byte)0x77, (byte)0x2C, (byte)0xC6, (byte)0xEA,
		(byte)0xB2, (byte)0x62, (byte)0x0D, (byte)0x2D,
		(byte)0x3C, (byte)0xDC, (byte)0x17, (byte)0xBB,
		(byte)0xC2, (byte)0x6C, (byte)0x4F, (byte)0x68
	};
	public static final byte[] z64header = new byte[] {
		(byte)0x80, (byte)0x37, (byte)0x12, (byte)0x40
	};
	public static final byte[] n64header = new byte[] {
		(byte)0x37, (byte)0x80, (byte)0x40, (byte)0x12
	};
	public static final byte[] v64header = new byte[] {
		(byte)0x40, (byte)0x12, (byte)0x37, (byte)0x80
	};
	public static final byte[] checksums = new byte[] {
		(byte)0x8A, (byte)0x60, (byte)0x09, (byte)0xB6,
		(byte)0x94, (byte)0xAC, (byte)0xE1, (byte)0x50
	};

	// General utility functions

	// XXX Refactor into library

	public static boolean DEBUG = false;

	private static void log(String message) {
		if (DEBUG) System.out.println(message);
	}

	public static int __argIndex = 0;

	public static abstract class FetchArgument {
		public abstract Object fetch(String description);
	}

	public static abstract class StringArgConverter {
		public abstract Object convert(String input);
	}

	public static Object initializeFromArgument(
		String[] args, int index,
		FetchArgument fetch, String description,
		StringArgConverter converter
	) {
		__argIndex = index + 1;
		Object output = null;
		String obtained = null;
		try {
			obtained = args[index];
		} catch (Exception ex) { }
		if (obtained != null && !obtained.isEmpty()) {
			output = converter.convert(obtained);
		}
		if (output == null)
			output = fetch.fetch(description);
		return output;
	}

	public static Object initializeFromArgument(
		String[] args,
		FetchArgument fetch, String description,
		StringArgConverter converter
	) {
		return initializeFromArgument(
			args, __argIndex,
			fetch, description,
			converter
		);
	}

	private static File fileHelper(String title, int mode) {
		java.awt.FileDialog chooser = new java.awt.FileDialog(
			new java.awt.Frame(), title, mode
		);
		chooser.setVisible(true);
		chooser.setLocationRelativeTo(null);

		String directory = chooser.getDirectory();
		String file = chooser.getFile();

		if (directory == null || file == null) { return null; }
		return new File(directory + file);
	}

	public static File showOpenFileDialog(String what) {
		return fileHelper(
			"Select " + what + " for opening",
			java.awt.FileDialog.LOAD
		);
	}

	public static File showSaveFileDialog(String what) {
		return fileHelper(
			"Select path to save " + what,
			java.awt.FileDialog.SAVE
		);
	}

	public static byte[] readAllBytes(File file) {
		byte[] fileData;
		FileInputStream fileInputStream = null;
		fileData = new byte[(int)file.length()];
		try {
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(fileData);
		} catch (Exception e) {}
		try { fileInputStream.close(); } catch (Exception e) {}
		return fileData;
	}

	public static byte[] getFileData(String description) {
		File file = showOpenFileDialog(description);
		return readAllBytes(file);
	}

	public static void writeAllBytes(File outputDest, byte[] output) {
		FileOutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(outputDest);
			outputStream.write(output);
		} catch (Exception e) {}
		try { outputStream.close(); } catch (Exception e) {}
	}

	public static void putFileData(String description, byte[] output) {
		File outputDest = showSaveFileDialog(description);
		writeAllBytes(outputDest, output);
	}

	public static byte[] fileGetter(
		String[] args, int index, String desc
	) {
		return (byte[])initializeFromArgument(
			args, index,
			new FetchArgument() {
				@Override
				public Object fetch(String description) {
					return getFileData(description);
				}
			},
			desc,
			new StringArgConverter() {
				@Override
				public Object convert(String input) {
					return readAllBytes(new File(input));
				}
			}
		);
	}

	public static byte[] fileGetter(
		String[] args, String desc
	) {
		return fileGetter(args, __argIndex, desc);
	}

	public static void fileSaver(
		String[] args, int index, String desc, final byte[] outputData
	) {
		initializeFromArgument(
			args, index,
			new FetchArgument() {
				@Override
				public Object fetch(String description) {
					putFileData(description, outputData);
					return true;
				}
			},
			desc,
			new StringArgConverter() {
				@Override
				public Object convert(String input) {
					writeAllBytes(new File(input), outputData);
					return true;
				}
			}
		);
	}

	public static void fileSaver(
		String[] args, String desc, final byte[] outputData
	) {
		fileSaver(args, __argIndex, desc, outputData);
	}

	public static String byteArrayToString(byte[] input) {
		if (input == null || input.length == 0)
			return null;

		String outputString = "";
		for (int i = 0; i < input.length; i++)
			outputString += String.format("%02X ", input[i] & 0xFF);
		return outputString.substring(0, outputString.length() - 1);
	}

	// Use this to make drivers
	private static abstract class Run {
		public abstract void execute(String[] args);
	}

	// Methods for program logic

	// 8 bit swap
	public static byte[] eightSwap(byte[] input) {
		for (int i = 0; i < input.length; i += 2) {
			byte byte1 = input[i];
			input[i] = input[i + 1];
			input[i + 1] = byte1;
		}
		return input;
	}

	// 16 bit swap
	public static byte[] sixteenSwap(byte[] input) {
		for (int i = 0; i < input.length; i += 4) {
			byte byte1 = input[i];
			byte byte2 = input[i + 1];
			input[i] = input[i + 2];
			input[i + 1] = input[i + 3];
			input[i + 2] = byte1;
			input[i + 3] = byte2;
		}
		return input;
	}

	// Drivers

	// Tested and working
	private static class Patcher extends Run {
		public void execute(String[] args) {
			byte[] file = fileGetter(args, "Jet Force Gemini");
			if (file.length != correctLength)
				throw new RuntimeException("That file has incorrect length!");
			// Read the "header"
			byte[] header = new byte[4];
			System.arraycopy(file, 0, header, 0, header.length);
			if (java.util.Arrays.equals(header, n64header))
				// It's an N64; byte swap it
				file = eightSwap(file);
			else if (java.util.Arrays.equals(header, v64header))
				// It's a V64; byte AND word swap it
				file = sixteenSwap(eightSwap(file));
			else if (!java.util.Arrays.equals(header, z64header))
				// If there's no match we have a problem
				throw new RuntimeException(
					"The provided file does not appear " +
					"to be Jet Force Gemini (U)."
				);
			// Fix the checksums
			System.arraycopy(checksums, 0, file, 16, checksums.length);
			// Check the MD5
			MessageDigest md = null;
			try {
				md = MessageDigest.getInstance("MD5");
			} catch (Exception ex) { return; }
			byte[] md5 = md.digest(file);
			if (!java.util.Arrays.equals(md5, correctMD5))
				throw new RuntimeException(
					"MD5 mismatch; something is corrupt " +
					"or you're using the wrong file"
				);
			fileSaver(args, "Z64 formatted Jet Force Gemini", file);
		}
	}

	// Change this and build again to use a different tool,
	// or change it programmatically before calling run.execute(args)
	// to simulate multiple utilities
	private static Run run = new Patcher();

	// Main

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(
				UIManager.getSystemLookAndFeelClassName()
			);
			run.execute(args);
		} catch (Exception e) {
			final Writer result = new StringWriter();
			final PrintWriter printWriter = new PrintWriter(result);
			e.printStackTrace(printWriter);
			JTextArea errorDisplayArea = new JTextArea(
				"Exception: " +
				e.getMessage() +
				"\n" +
				result.toString()
			);
			JScrollPane errorPane = new JScrollPane(errorDisplayArea);
			JOptionPane.showMessageDialog(
				null,
				errorPane,
				"Error",
				JOptionPane.ERROR_MESSAGE
			);
		}
		System.exit(0);
	}
}
